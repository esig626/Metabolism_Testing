# Phase 2A Raw Search Results

These are prospective snapshots and verification materials created on
2026-07-31. Phase 2 identifiers are independent of Phase 1 `SEARCH` and
`REPAIR-SEARCH` identifiers. No Phase 1 screening file is regenerated from
this directory.

- `A/`: 13C-MFA tracer, measurement, parallel and dynamic experimental
  design.
- `B/`: metabolic model validation/discrimination and nearest biochemical
  design methods.
- `C/`: adjacent decision theory, robust testing and controlled sensing.
- `D/`: model misspecification, mapping and network-adequacy methods.
- `E/`: software repositories, documentation and primary software papers.

The five directories contain raw JSON/XML/HTML or archive snapshots,
per-workstream documentation, and the C/D deterministic ledger builders.
JSON and XML files are unmodified service responses where practical. Any
exact metadata normalization in a derived ledger is documented in its
builder; raw responses are not rewritten.

Primary full-text XML/HTML stored here is legally accessible repository or
publisher content used for verification. It is kept separate from the
curated evidence rows. Structured supplementary-web snapshots in Workstream B
are labelled as transcriptions and are not represented as database-native
exports.

Supplementary routes without native result exports are mapped explicitly:

- PHASE2-SEARCH-0015 → `B/P0031-juser-record.html`;
- PHASE2-SEARCH-0016 → `B/P0032-arxiv-metadata.xml`;
- PHASE2-SEARCH-0039 → `D/P0035-PMC5590471-fulltext.xml`;
- PHASE2-SEARCH-0040 → `D/P0034-PMC8878866-fulltext.xml`; and
- PHASE2-SEARCH-0111 → the separately keyed 0111 entry in
  `B/PHASE2-SEARCH-0110-0112_web_snapshot.json`.

These files preserve the structured transcription or the primary/official
route that was actually retained. They do not reconstruct an unavailable
native search-result export or result universe.

Failed or incomplete retrievals remain explicit:

- PHASE2-SEARCH-0012 returned zero records.
- PHASE2-SEARCH-0036 preserves a failed API response and contributes no
  discovery row.
- The unresolved OpenAlex identifier in PHASE2-SEARCH-0106 is
  `AWAITING_VERIFICATION`.
- PHASE2-SEARCH-0093 records the unavailable WUFlux project host; capability
  evidence comes from the accessible primary paper.

The authoritative exact query text, filters and result counts are in
`audit/phase2_search_log_A.md` through
`audit/phase2_search_log_E.md`. The consolidated occurrence ledger is
`audit/phase2_screening.csv`; its deterministic builder is
`scripts/build_phase2_screening.pl`.
