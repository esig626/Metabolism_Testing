# Workstream A raw search snapshots

Created prospectively on 2026-07-31 UTC. Files named
`PHASE2-SEARCH-####_*` are unmodified JSON API responses for the exact
queries in `audit/phase2_search_log_A.md`.

`pubmed_esummary_union.json` is the ESummary metadata retrieval for the union
of PubMed IDs returned by PHASE2-SEARCH-0001, 0003, 0005 and 0007. It is a
metadata companion, not an additional discovery search.

OpenAlex and Crossref snapshots contain the bounded first result page
specified in the log. Their API total counts can exceed the number of
discovered records; only records physically present in these snapshots enter
`audit/phase2_screening_A.csv`.

PHASE2-SEARCH-0056–0060 are a bounded closure pass. SEARCH-0056 is a
structured extraction of the six inspected primary full-text reference
lists. SEARCH-0057 has a separate PubMed ESummary companion. SEARCH-0058 and
0059 are distinct-source dynamic-design queries, and SEARCH-0060 is the
OpenAlex forward-citation result page for the Nöh–Wiechert 2006 anchor.
Their prospective occurrence-level dispositions are preserved separately in
`audit/phase2_screening_A_closure.csv`.
