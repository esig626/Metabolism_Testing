# Workstream D raw-search material

All material was preserved prospectively on 2026-07-31 and is independent of
Phase 1 provenance.

- PHASE2-SEARCH-0036 preserves the failed PubMed response and contributes no
  screening occurrence.
- PHASE2-SEARCH-0037 and 0038 preserve the successful PubMed/OpenAlex
  structured responses.
- PHASE2-SEARCH-0039 and 0040 were supplementary web-routing searches whose
  sources exposed neither native result exports nor total counts.
  `P0035-PMC5590471-fulltext.xml` and
  `P0034-PMC8878866-fulltext.xml` preserve the complete primary texts
  reached by those routes. They verify the retained works but do not
  reconstruct the unavailable search-result universes.
- PHASE2-SEARCH-0104 preserves the bounded Crossref response.
- PHASE2-SEARCH-0105 and 0106 preserve anchor, backward-reference and
  forward-citation responses separately. OpenAlex identifier `W6604903323`
  did not resolve in the bounded 0106 metadata response and remains
  `AWAITING_VERIFICATION`.

`build_screening_closure.pl` deterministically generates
`audit/phase2_screening_D_closure.csv` from the preserved 0104–0106
responses. It does not infer metadata for unresolved records.
