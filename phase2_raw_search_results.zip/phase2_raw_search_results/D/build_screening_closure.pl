#!/usr/bin/env perl
use strict;
use warnings;
use utf8;
use open qw(:std :encoding(UTF-8));
use JSON::PP qw(decode_json);

my $root = 'audit/phase2_raw_search_results/D';
my $out = 'audit/phase2_screening_D_closure.csv';
my $date = '2026-07-31';

sub load_json {
    my ($path) = @_;
    # JSON::PP::decode_json expects UTF-8 octets and performs the decode.
    open my $fh, '<:raw', $path or die "$path: $!";
    local $/;
    return decode_json(<$fh>);
}

sub clean {
    my ($value) = @_;
    $value //= '';
    $value =~ s/\s+/ /g;
    $value =~ s/^\s+|\s+$//g;
    return $value;
}

sub canonical_doi {
    my ($doi) = @_;
    $doi = lc clean($doi);
    $doi =~ s{^https?://doi\.org/}{};
    return $doi;
}

sub csv_quote {
    my ($value) = @_;
    $value //= '';
    $value =~ s/"/""/g;
    return qq{"$value"};
}

my %existing_corpus = (
    '10.1002/bit.21632'              => 'P0013',
    '10.1016/j.ymben.2011.08.002'    => 'P0014',
    '10.1016/j.ymben.2014.08.002'    => 'P0015',
    '10.1016/j.ymben.2012.06.003'    => 'P0033',
    '10.3390/metabo12020122'          => 'P0034',
    '10.3390/bioengineering4020048'   => 'P0035',
);

# These are version links to already-curated final publications, not inferred
# methodological classifications.
my %superseded_version = (
    '10.1101/2021.10.05.463172'       => 'P0034',
    '10.20944/preprints201703.0124.v1'=> 'P0035',
);

# Primary/adjacent leads retained at discovery level only. No substantive
# conclusion in the handoff relies on these title/metadata decisions.
my %discovery_lead = map { $_ => 1 } qw(
    10.1038/s41598-021-87643-8
    10.1007/s11047-014-9419-8
    10.1016/j.jmva.2005.03.010
    10.1515/9781400829385-011
    10.1177/0013164412452564
    10.1007/978-3-642-58324-7_2
    10.1177/0962280214544251
    10.1038/s41467-019-09440-2
    10.1093/bioinformatics/btw096
    10.1021/ci3002217
    10.1021/ci200351b
    10.1186/s13321-017-0223-1
    10.3390/metabo11070431
    10.1039/d3sc02048g
    10.1186/s13015-025-00294-6
    10.3390/metabo13121199
    10.3390/metabo16060357
    10.1021/acssynbio.6c00060
    10.1111/j.2517-6161.1969.tb00796.x
    10.1002/(sici)1097-0290(19970705)55:1<118::aid-bit13>3.0.co;2-i
    10.1002/bit.260430103
    10.1002/bit.260250906
    10.1002/bit.260430104
    10.1080/00031305.1971.10477302
    10.2307/20076563
    10.1177/0049124192021002003
    10.1002/bit.24926
);

my %duplicate_version = (
    '10.26434/chemrxiv-2022-bn5nt' => '10.1021/acs.jcim.2c00344',
    '10.31234/osf.io/s47xz_v1'     => '10.31234/osf.io/s47xz_v2',
    '10.1101/050187'               => '10.1016/j.ymben.2019.09.006',
    '10.3102/2012345'              => '10.3102/ip.23.2012345',
    '10.1101/2021.06.01.446673'    => '10.3390/metabo11070431',
);

my @rows;
my $sequence = 0;
my %seen;

sub decide {
    my ($doi, $title, $type, $source) = @_;

    if ($doi eq '10.1186/s12918-016-0335-7') {
        if (!$seen{$doi}++) {
            return (
                'FULL_TEXT_INCLUDED', 'NA', 'LEVEL_1_LOAD_BEARING',
                'P0045', 'D-CLOSE-P0045',
                'Complete primary full text inspected; exact evidence is recorded in the Workstream D handoff.'
            );
        }
        return (
            'DUPLICATE', 'DUPLICATE_OF_EARLIER_PHASE2_OCCURRENCE',
            'LEVEL_3_DISCOVERY_ONLY', 'P0045', 'D-CLOSE-P0045',
            'The complete source was already included from PHASE2-SEARCH-0104.'
        );
    }

    if (my $id = $existing_corpus{$doi}) {
        return (
            'DUPLICATE', 'DUPLICATE_OF_CURATED_CORPUS_RECORD',
            'LEVEL_3_DISCOVERY_ONLY', $id, "D-CLOSE-$id",
            'The DOI is already represented by the stated stable corpus ID.'
        );
    }

    if (my $id = $superseded_version{$doi}) {
        return (
            'DUPLICATE', 'SUPERSEDED_VERSION_OF_CURATED_CORPUS_RECORD',
            'LEVEL_3_DISCOVERY_ONLY', $id, "D-CLOSE-$id",
            'The preserved result is a preprint/version of the curated final publication.'
        );
    }

    if ($doi eq '10.1002/btpr.3413') {
        return (
            'DUPLICATE', 'DUPLICATE_OF_EARLIER_PHASE2_DISCOVERY',
            'LEVEL_3_DISCOVERY_ONLY', '', 'D-CLOSE-BTPR3413',
            'This article was prospectively discovered by earlier Phase 2 searches.'
        );
    }

    if (my $final = $duplicate_version{$doi}) {
        return (
            'DUPLICATE', "DUPLICATE_OR_SUPERSEDED_BY_$final",
            'LEVEL_3_DISCOVERY_ONLY', '', "D-CLOSE-$final",
            'Version relationship is explicit in the preserved identifiers/titles.'
        );
    }

    if ($discovery_lead{$doi}) {
        return (
            'TITLE_ABSTRACT_INCLUDED', 'NA', 'LEVEL_3_DISCOVERY_ONLY', '',
            "D-CLOSE-$doi",
            'Adjacent discovery lead only; no full-text or guarantee claim was extracted for Phase 2 synthesis.'
        );
    }

    if (($type // '') =~ /peer-review|component/ ||
        $doi =~ m{/v[12]/(?:review|decision|response)\d*$} ||
        $doi =~ /\.s\d+$/) {
        return (
            'TITLE_ABSTRACT_EXCLUDED',
            'PROCEDURAL_OR_SUPPLEMENTARY_RECORD_WITHOUT_STANDALONE_METHOD_EVIDENCE',
            'LEVEL_3_DISCOVERY_ONLY', '', "D-CLOSE-$doi",
            'Prospective title/metadata exclusion.'
        );
    }

    if ($title =~ /atom[- ]to[- ]atom mapping|atom mapping|reaction mapping|harmonization/i) {
        return (
            'TITLE_ABSTRACT_EXCLUDED',
            'ATOM_MAPPING_OR_CURATION_METHOD_WITHOUT_INFERENCE_OR_ROBUST_DESIGN_TREATMENT',
            'LEVEL_3_DISCOVERY_ONLY', '', "D-CLOSE-$doi",
            'The record may prevent mapping errors but does not, from the preserved metadata, model their effect on MFA decisions.'
        );
    }

    if ($title =~ /review|guide|chapter|perspective|database|KEGG|MetaCyc|BRENDA|Rhea|InChI|What is flux balance/i) {
        return (
            'TITLE_ABSTRACT_EXCLUDED',
            'SECONDARY_OR_GENERAL_CONTEXT_WITHOUT_NEW_PRIMARY_MISSPECIFICATION_METHOD',
            'LEVEL_3_DISCOVERY_ONLY', '', "D-CLOSE-$doi",
            'Prospective title/metadata exclusion.'
        );
    }

    return (
        'TITLE_ABSTRACT_EXCLUDED',
        'NO_DIRECT_METHOD_FOR_FORWARD_MODEL_MISSPECIFICATION_OR_ROBUST_DISCRIMINATION',
        'LEVEL_3_DISCOVERY_ONLY', '', "D-CLOSE-$doi",
        'Prospective title/metadata exclusion; no stronger conclusion was inferred.'
    );
}

sub add_row {
    my (%r) = @_;
    $sequence++;
    my ($state, $reason, $level, $final_id, $dup_group, $notes) =
        decide($r{doi}, $r{title}, $r{type}, $r{source});
    push @rows, [
        sprintf('DCL%04d', $sequence), $r{source}, $r{query_id}, $date,
        clean($r{title}), clean($r{authors}), clean($r{year}),
        ($r{doi} || clean($r{native_id})), clean($r{native_id}),
        clean($r{anchor}), $dup_group, $state, $reason, $level, $final_id,
        $r{raw_file}, $notes,
    ];
}

my $crossref_file = "$root/PHASE2-SEARCH-0104_crossref.json";
my $crossref = load_json($crossref_file);
my @crossref_items = @{$crossref->{message}{items} // []};
die "PHASE2-SEARCH-0104 expected 50 records, got " . scalar(@crossref_items)
    unless @crossref_items == 50;
for my $r (@crossref_items) {
    my $year = $r->{published}{'date-parts'}[0][0]
        // $r->{issued}{'date-parts'}[0][0] // '';
    add_row(
        source => 'Crossref', query_id => 'PHASE2-SEARCH-0104',
        title => ref($r->{title}) ? ($r->{title}[0] // '') : ($r->{title} // ''),
        authors => join('; ', grep { length } map {
            clean(join(' ', grep { length } ($_->{given} // '', $_->{family} // '')))
        } @{$r->{author} // []}),
        year => $year, doi => canonical_doi($r->{DOI}),
        native_id => ($r->{DOI} // $r->{URL} // ''),
        type => ($r->{type} // ''), anchor => '',
        raw_file => $crossref_file,
    );
}

for my $q (
    {
        id => 'PHASE2-SEARCH-0105',
        anchor_file => "$root/PHASE2-SEARCH-0105_anchor_openalex.json",
        backward_file => "$root/PHASE2-SEARCH-0105_backward_openalex.json",
        forward_file => "$root/PHASE2-SEARCH-0105_forward_openalex.json",
        anchor_doi => '10.3390/metabo12020122',
        anchor_openalex => 'W4210780466',
        backward_expected => 24, forward_expected => 9,
    },
    {
        id => 'PHASE2-SEARCH-0106',
        anchor_file => "$root/PHASE2-SEARCH-0106_anchor_openalex.json",
        backward_file => "$root/PHASE2-SEARCH-0106_backward_openalex.json",
        forward_file => "$root/PHASE2-SEARCH-0106_forward_openalex.json",
        anchor_doi => '10.3390/bioengineering4020048',
        anchor_openalex => 'W2601725879',
        backward_expected => 28, forward_expected => 1,
    },
) {
    my $anchor = load_json($q->{anchor_file});
    my $anchor_id = $anchor->{id} // '';
    die "$q->{id} anchor mismatch"
        unless canonical_doi($anchor->{doi}) eq $q->{anchor_doi}
        && $anchor_id =~ /\Q$q->{anchor_openalex}\E$/;
    my $anchor_citation = "$q->{anchor_doi} ($q->{anchor_openalex})";
    add_row(
        source => 'OpenAlex anchor verification', query_id => $q->{id},
        title => ($anchor->{title} // ''),
        authors => join('; ', map {
            $_->{author}{display_name} // ()
        } @{$anchor->{authorships} // []}),
        year => ($anchor->{publication_year} // ''),
        doi => canonical_doi($anchor->{doi}), native_id => $anchor_id,
        type => ($anchor->{type} // ''), anchor => $anchor_citation,
        raw_file => $q->{anchor_file},
    );

    my $backward = load_json($q->{backward_file});
    my @backward_items = @{$backward->{results} // []};
    die "$q->{id} backward expected $q->{backward_expected}, got "
        . scalar(@backward_items)
        unless @backward_items == $q->{backward_expected};
    for my $r (@backward_items) {
        add_row(
            source => 'OpenAlex backward citations', query_id => $q->{id},
            title => ($r->{title} // ''),
            authors => join('; ', map {
                $_->{author}{display_name} // ()
            } @{$r->{authorships} // []}),
            year => ($r->{publication_year} // ''),
            doi => canonical_doi($r->{doi}), native_id => ($r->{id} // ''),
            type => ($r->{type} // ''), anchor => $anchor_citation,
            raw_file => $q->{backward_file},
        );
    }

    if ($q->{id} eq 'PHASE2-SEARCH-0106') {
        my %resolved = map {
            my $id = $_->{id} // '';
            $id =~ s{.*/}{};
            ($id => 1)
        } @backward_items;
        my @missing;
        for my $ref (@{$anchor->{referenced_works} // []}) {
            (my $id = $ref) =~ s{.*/}{};
            push @missing, $id unless $resolved{$id};
        }
        die "PHASE2-SEARCH-0106 expected one unresolved backward ID"
            unless @missing == 1 && $missing[0] eq 'W6604903323';
        $sequence++;
        push @rows, [
            sprintf('DCL%04d', $sequence), 'OpenAlex backward citation ID',
            $q->{id}, $date, '', '', '', 'W6604903323',
            'https://openalex.org/W6604903323', $anchor_citation,
            'D-CLOSE-W6604903323', 'AWAITING_VERIFICATION', 'NA',
            'LEVEL_3_DISCOVERY_ONLY', '', $q->{anchor_file},
            'The anchor lists this reference ID, but the preserved bounded metadata resolution returned no record; no bibliographic or eligibility inference was made.',
        ];
    }

    my $forward = load_json($q->{forward_file});
    my @forward_items = @{$forward->{results} // []};
    die "$q->{id} forward expected $q->{forward_expected}, got "
        . scalar(@forward_items)
        unless @forward_items == $q->{forward_expected};
    for my $r (@forward_items) {
        add_row(
            source => 'OpenAlex forward citations', query_id => $q->{id},
            title => ($r->{title} // ''),
            authors => join('; ', map {
                $_->{author}{display_name} // ()
            } @{$r->{authorships} // []}),
            year => ($r->{publication_year} // ''),
            doi => canonical_doi($r->{doi}), native_id => ($r->{id} // ''),
            type => ($r->{type} // ''), anchor => $anchor_citation,
            raw_file => $q->{forward_file},
        );
    }
}

die "Expected 115 prospective occurrences, got " . scalar(@rows)
    unless @rows == 115;

open my $out_fh, '>:encoding(UTF-8)', $out or die "$out: $!";
print {$out_fh} join(',', map { csv_quote($_) } qw(
    workstream_record_id search_source query_id search_date title authors year
    doi_or_identifier source_native_id citation_anchor duplicate_group
    screening_state exclusion_reason evidence_level final_corpus_id
    raw_result_file notes
)), "\n";
for my $row (@rows) {
    print {$out_fh} join(',', map { csv_quote($_) } @$row), "\n";
}
close $out_fh or die "$out: $!";

my %count;
$count{$_->[11]}++ for @rows;
print STDERR join(', ', map { "$_=$count{$_}" } sort keys %count), "\n";
