# Workstream E raw prospective results

This directory contains the structured API responses for
PHASE2-SEARCH-0041–0055 and the bounded closure
PHASE2-SEARCH-0069–0074 plus named-lead closure
PHASE2-SEARCH-0090–0093, executed 2026-07-31. Files ending
`_summary.json` retrieve PubMed metadata for identifiers already returned by
the matching `_pubmed.json` search and are not additional discovery searches.

GitHub and JuGit repository endpoints are authoritative project metadata.
Crossref and PubMed are bibliographic discovery/verification sources, not
capability evidence. Exact repository paths and commits used for capability
verification are recorded in `analyses/phase2_software_landscape.md`.

The closure also preserves official HTML for Metran and PMC BioC XML for
13CFLUX(v3), BayFlux and FreeFlux. These are raw primary/official snapshots;
their non-JSON format is intentional. PHASE2-SEARCH-0074 has two XML files
because one bounded citation pass inspected two prespecified principal
software papers.

Crossref snapshots preserve the first ten returned records for the exact
queries in `audit/phase2_search_log_E.md`. No result-count estimate is treated
as a screened record beyond the ten objects actually exported. All exported
objects have prospective dispositions in `audit/phase2_screening_E.csv`.

PHASE2-SEARCH-0090 preserves SourceForge project metadata; its official Git
revision and inspected paths are recorded in the analysis and handoff.
PHASE2-SEARCH-0091 preserves both the DOI-to-PMC lookup and complete FiatFlux
primary text. PHASE2-SEARCH-0093 is a structured retrieval-failure record,
not an inference that WUFlux capabilities are absent.
