#!/usr/bin/env perl
use strict;
use warnings;
use utf8;
use open qw(:std :encoding(UTF-8));
use JSON::PP qw(decode_json);
use Text::ParseWords qw();

my $root = 'audit/phase2_raw_search_results/C';
my @files = sort glob "$root/PHASE2-SEARCH-*.json";
my %group_for_key;
my %occurrence_count;
my @rows;
my $sequence = 0;

sub csv {
    my ($v) = @_;
    $v //= '';
    $v =~ s/"/""/g;
    return qq{"$v"};
}

sub canonical_doi {
    my ($d) = @_;
    $d //= '';
    $d = lc $d;
    $d =~ s{^https?://doi\.org/}{};
    return $d;
}

sub clean {
    my ($v) = @_;
    $v //= '';
    $v =~ s/\s+/ /g;
    $v =~ s/^\s+|\s+$//g;
    return $v;
}

my %full = map { $_ => 1 } qw(
  10.1214/08-aos635
  10.1186/1752-0509-4-38
  10.1080/07474946.2021.1912525
  10.1109/tit.2017.2693198
  10.1093/jrsssb/qkae011
  10.1109/tit.2008.2008128
);
my %corpus_id = (
  '10.1214/08-aos635' => 'P0038',
  '10.1186/1752-0509-4-38' => 'P0039',
  '10.1080/07474946.2021.1912525' => 'P0028',
  '10.1109/tit.2017.2693198' => 'P0041',
  '10.1093/jrsssb/qkae011' => 'P0043',
  '10.1109/tit.2008.2008128' => 'P0044',
  '10.1214/15-aos1333' => 'P0040',
);

my $relevant = qr{
    optimal\s+discrimin
  | model\s+discrimin
  | controlled\s+sensing
  | active\s+(?:sequential\s+)?hypothesis
  | composite\s+(?:multi)?hypothesis
  | minimax\s+robust\s+hypothesis
  | robust\s+hypothesis
  | nondegenerate\s+vuong
  | nonnested
  | best.arm\s+identification
  | sequential\s+design\s+of\s+experiments
  | testing\s+hypotheses\s+on\s+independent
  | robust\s+testing\s+for\s+independent
  | nuisance\s+parameters
  | safe\s+testing
  | relative\s+entropy\s+tolerance
}ix;

for my $file (@files) {
    next if $file =~ /_anchor_openalex\.json$/;
    # JSON::PP::decode_json expects UTF-8 octets and performs the decode.
    open my $fh, '<:raw', $file or die "$file: $!";
    local $/;
    my $j = decode_json(<$fh>);
    my ($qid) = $file =~ /(PHASE2-SEARCH-\d{4})/;
    my $source = $file =~ /openalex/ ? 'OpenAlex' : 'Crossref';
    my @items = $source eq 'OpenAlex' ? @{$j->{results} // []} : @{$j->{message}{items} // []};
    for my $r (@items) {
        my ($title, $authors, $year, $doi, $identifier, $native_id);
        if ($source eq 'OpenAlex') {
            $title = $r->{title} // '';
            $authors = join '; ', map { $_->{author}{display_name} // () } @{$r->{authorships} // []};
            $year = $r->{publication_year} // '';
            $doi = canonical_doi($r->{doi});
            $identifier = $doi || ($r->{id} // '');
            $native_id = $r->{id} // '';
        } else {
            $title = ref($r->{title}) ? ($r->{title}[0] // '') : ($r->{title} // '');
            $authors = join '; ', map {
                join(' ', grep { length } ($_->{given} // '', $_->{family} // ''))
            } @{$r->{author} // []};
            $year = $r->{published}{'date-parts'}[0][0] // '';
            $doi = canonical_doi($r->{DOI});
            $identifier = $doi || ($r->{URL} // '');
            $native_id = $r->{DOI} // $r->{URL} // '';
        }
        ($title, $authors, $year, $identifier) =
            map { clean($_) } ($title, $authors, $year, $identifier);
        my $key = $doi || lc($title);
        $key =~ s/\s+/ /g;
        my $group = $group_for_key{$key};
        if (!defined $group) {
            $group = sprintf(
                'C-DUP-%04d', scalar(keys %group_for_key) + 1
            );
            $group_for_key{$key} = $group;
        }
        my ($state, $reason);
        if ($occurrence_count{$key}++) {
            $state = 'DUPLICATE';
            $reason = 'Duplicate DOI or normalized title of an earlier Phase 2 record.';
        } elsif ($full{$doi}) {
            $state = 'FULL_TEXT_INCLUDED';
            $reason = '';
        } elsif ($title =~ $relevant) {
            $state = 'TITLE_ABSTRACT_INCLUDED';
            $reason = '';
        } else {
            $state = 'TITLE_ABSTRACT_EXCLUDED';
            $reason = 'Not directly relevant to adjacent model-discrimination or decision-theory transfer after title/metadata screening.';
        }
        my $level = $state eq 'DUPLICATE' ? 'LEVEL_3_DISCOVERY_ONLY' :
            $full{$doi} ? 'LEVEL_1_LOAD_BEARING' :
            'LEVEL_3_DISCOVERY_ONLY';
        push @rows, [
            sprintf('C%04d', ++$sequence), $qid, $source, '2026-07-31',
            $title, $authors, $year, $identifier, clean($native_id), $group,
            $state, $reason, $level, ($corpus_id{$doi} // ''), $file,
            "Prospective Workstream C occurrence; raw snapshot: $file",
        ];
    }
}

sub group_for {
    my ($identifier, $title) = @_;
    my $key = canonical_doi($identifier) || lc clean($title);
    return $group_for_key{$key} if defined $group_for_key{$key};
    my $group = sprintf(
        'C-DUP-%04d', scalar(keys %group_for_key) + 1
    );
    $group_for_key{$key} = $group;
    return $group;
}

# Supplementary discovery during PHASE2-SEARCH-0034 was verified on the
# official PMLR page and is kept distinct from the Crossref result set.
push @rows, [
    sprintf('C%04d', ++$sequence), 'PHASE2-SEARCH-0024',
    'PMC supplementary discovery', '2026-07-31',
    'Bayesian T-optimal discriminating designs',
    'Holger Dette; Viatcheslav B. Melas; Roman Guchenko', '2015',
    '10.1214/15-AOS1333', '10.1214/15-AOS1333',
    group_for('10.1214/15-AOS1333', 'Bayesian T-optimal discriminating designs'),
    'FULL_TEXT_INCLUDED', '', 'LEVEL_1_LOAD_BEARING', 'P0040',
    "$root/PMC4793413_fulltext.xml",
    "Supplementary primary-source discovery; raw full text: $root/PMC4793413_fulltext.xml",
];

push @rows, [
    sprintf('C%04d', ++$sequence), 'PHASE2-SEARCH-0034',
    'PMLR supplementary discovery', '2026-07-31',
    'Optimal Best Arm Identification with Fixed Confidence',
    'Aurélien Garivier; Emilie Kaufmann', '2016', 'PMLR-v49-garivier16a',
    'PMLR-v49-garivier16a',
    group_for('PMLR-v49-garivier16a',
        'Optimal Best Arm Identification with Fixed Confidence'),
    'FULL_TEXT_INCLUDED', '', 'LEVEL_1_LOAD_BEARING', 'P0042',
    "$root/PHASE2-SEARCH-0034_pmlr_supplementary.html",
    "Supplementary primary-source discovery; official snapshot: $root/PHASE2-SEARCH-0034_pmlr_supplementary.html",
];

push @rows, [
    sprintf('C%04d', ++$sequence), 'PHASE2-SEARCH-0067',
    'OpenAlex anchor verification', '2026-07-31',
    'Sequential controlled sensing for composite multihypothesis testing',
    'Abhishek Deshmukh; Venugopal V. Veeravalli; Srinivasa Bhashyam', '2021',
    '10.1080/07474946.2021.1912525',
    'https://openalex.org/W3179599115',
    group_for('10.1080/07474946.2021.1912525',
        'Sequential controlled sensing for composite multihypothesis testing'),
    'DUPLICATE',
    'Anchor record duplicates the earlier PHASE2-SEARCH-0027 record.',
    'LEVEL_3_DISCOVERY_ONLY', 'P0028',
    "$root/PHASE2-SEARCH-0067_anchor_openalex.json",
    "Anchor verification occurrence; raw snapshot: $root/PHASE2-SEARCH-0067_anchor_openalex.json",
];

push @rows, [
    sprintf('C%04d', ++$sequence), 'PHASE2-SEARCH-0068',
    'OpenAlex anchor verification', '2026-07-31',
    'Minimax Robust Hypothesis Testing',
    'Gökhan Gül; Abdelhak M. Zoubir', '2017',
    '10.1109/TIT.2017.2693198',
    'https://openalex.org/W2610642392',
    group_for('10.1109/TIT.2017.2693198', 'Minimax Robust Hypothesis Testing'),
    'DUPLICATE',
    'Anchor record duplicates the earlier PHASE2-SEARCH-0032 record.',
    'LEVEL_3_DISCOVERY_ONLY', 'P0041',
    "$root/PHASE2-SEARCH-0068_anchor_openalex.json",
    "Anchor verification occurrence; raw snapshot: $root/PHASE2-SEARCH-0068_anchor_openalex.json",
];

print join(',', map { csv($_) } qw(
  workstream_record_id query_id search_source search_date title authors year
  doi_or_identifier source_native_id duplicate_group screening_state
  exclusion_reason evidence_level final_corpus_id raw_result_file notes
)), "\n";
for my $row (@rows) {
    print join(',', map { csv($_) } @$row), "\n";
}
if ($ENV{SCREENING_STATS}) {
    my %count;
    $count{$_->[10]}++ for @rows;
    print STDERR join(', ', map { "$_=$count{$_}" } sort keys %count), "\n";
}
