# Workstream C raw material

The 34 JSON files are unmodified API responses obtained prospectively on
2026-07-31. OpenAlex responses contain the bounded result pages recorded in
the search log; Crossref responses contain the first 25 ranked results per
request. They are snapshots, not database-wide exports.

`PMC2873315_fulltext.xml` and `PMC4793413_fulltext.xml` are complete
open-access BioC XML representations returned by the NCBI service. The
PMLR HTML file is an official landing-page snapshot. The arXiv source archive
was retained because theorem and assumption locations in Gül and Zoubir
(2017) were checked against the primary TeX.

`build_screening.pl` deterministically creates
`audit/phase2_screening_C.csv`. It uses canonical DOI, or normalized title
when DOI is missing, for within-workstream deduplication. It contains an
explicit screening disposition and an exclusion reason for every prospective
exclusion. It does not read or modify the Phase 1 ledger.

The `PHASE2-SEARCH-0061`–`0068` files are the bounded closure pass.
For 0062, 0064 and 0066 both the initial Crossref response and one
`query.bibliographic` retry are retained. Files labelled `anchor`,
`backward`, and `forward` preserve the citation-network operation separately.
Unresolved OpenAlex references (one from each anchor) were not reconstructed.

`PHASE2-SEARCH-0080`–`0083` are the restored-backup audit closure. They are
two distinct-source query pairs aimed only at the residual shared-nuisance /
heterogeneous-batch and joint distributionally robust design stopping rules.
They added no load-bearing method family. The deterministic builder includes
their 100 prospective records in the screening ledger.
